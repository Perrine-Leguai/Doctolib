<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* accueil/pageAccueilHorsCo.html.twig */
class __TwigTemplate_16f99120222eb36f50636a7c705c3dffc7d82b62b0968ec038382d392cab456f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "accueil/pageAccueilHorsCo.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "accueil/pageAccueilHorsCo.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "accueil/pageAccueilHorsCo.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Accueil- Doctolib";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div id=\"main\" class=\"container d-flex justify-content-around\" >
        <div class=\"card  d-flex justify-content-center mt-5 offest-2\" >
            <div class=\"card-body\">
                <h3 class=\"card-title mb-5 mt-4 text-primary\">Bienvenu.e.s sur Doctolib</h3>
                <h5 class=\"card-subtitle mb-2 text-muted\">Le site de gestion des rendez vous médicaux</h5>
                <p class=\"card-text mt-2\">Prenez en un clic, rendez vous au près du practicien qu'il vous faut.<br> Vous êtes déjà plus de ";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["nombre_de_patients"]) || array_key_exists("nombre_de_patients", $context) ? $context["nombre_de_patients"] : (function () { throw new RuntimeError('Variable "nombre_de_patients" does not exist.', 11, $this->source); })()), "html", null, true);
        echo " patient.e.s et ";
        echo twig_escape_filter($this->env, (isset($context["nombre_de_docteurs"]) || array_key_exists("nombre_de_docteurs", $context) ? $context["nombre_de_docteurs"] : (function () { throw new RuntimeError('Variable "nombre_de_docteurs" does not exist.', 11, $this->source); })()), "html", null, true);
        echo " docteurs à nous faire confiance !</p>
                <a href=\"#";
        // line 12
        echo "\" class=\"card-link\">Inscription</a>
                <a href=\"#";
        // line 13
        echo "\" class=\"card-link\">Connexion</a> 
            </div>
        </div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "accueil/pageAccueilHorsCo.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 13,  101 => 12,  95 => 11,  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Accueil- Doctolib{% endblock %}

{% block body %}
    <div id=\"main\" class=\"container d-flex justify-content-around\" >
        <div class=\"card  d-flex justify-content-center mt-5 offest-2\" >
            <div class=\"card-body\">
                <h3 class=\"card-title mb-5 mt-4 text-primary\">Bienvenu.e.s sur Doctolib</h3>
                <h5 class=\"card-subtitle mb-2 text-muted\">Le site de gestion des rendez vous médicaux</h5>
                <p class=\"card-text mt-2\">Prenez en un clic, rendez vous au près du practicien qu'il vous faut.<br> Vous êtes déjà plus de {{nombre_de_patients}} patient.e.s et {{nombre_de_docteurs}} docteurs à nous faire confiance !</p>
                <a href=\"#{# {{path('/security/inscription_security')}}#}\" class=\"card-link\">Inscription</a>
                <a href=\"#{#{{path('/security/connexion_security')}}#}\" class=\"card-link\">Connexion</a> 
            </div>
        </div>
    </div>
{% endblock %}", "accueil/pageAccueilHorsCo.html.twig", "C:\\Users\\Terri\\Documents\\AFPA\\exo\\Doctolib\\Doctolib\\templates\\accueil\\pageAccueilHorsCo.html.twig");
    }
}
